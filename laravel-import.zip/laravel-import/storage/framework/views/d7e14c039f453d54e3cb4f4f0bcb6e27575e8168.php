<!DOCTYPE html>
<html>
<head>
    <title>Laravel Export Excel to Database - w3alert.com</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
</head>
<body>
   
<div class="container">
    <div class="card mt-4">
        <div class="card-header">
            Laravel 6 Export Excel to Database - w3alert.com
        </div>
        <div class="card-body">
    
          <a class="btn btn-info" href="<?php echo e(url('export')); ?>">Export File</a>

        </div>
    </div>
</div>
   
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel-export\resources\views/export.blade.php ENDPATH**/ ?>